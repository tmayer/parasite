
Parallel Bible Corpus
=====================

* Name: aai-x-bible-arifa-v0
* Copyright: © Wycliffe Bible Translators, Inc. 2009
* Title: Tur Gewasin O Baibasit Boubon The New Testament in the Miniafia Language of Oro Province, Papua New Guinea
* Year of translation: 2009
* Copyright (long version): TUR GEWASIN O BAIBASIT BOUBUN The New Testament in the Miniafia Language of Oro Province, Papua New Guinea  copyright © 2009 Wycliffe Bible Translators, Inc. Print publisher: Wycliffe Bible Translators, BibleLeague, and PNG Bible Translation Association Electronic publisher: PNG Bible Translation Association Translation by: PNG Bible Translation Association and Wycliffe Bible Translators  This translation is made available to you under the terms of the Attribution-noncommercial-no derivatives. In addition, you have permission to port the text to different file formats, as long as you don't change any of the text or punctuation of the Bible.  Pictures included with Scriptures and other documents on this site are licensed just for use with those Scriptures and documents. For other uses, please contact the respective copyright owners.  You may share, copy, distribute, transmit, and extract portions or quotations from this work, provided that: You include the above copyright information and that you make it clear that the work came from http://png scriptures.org/. You do not sell this work for a profit. You do not make any derivative works that change any of the actual words or punctuation of the Scriptures. Permissions beyond the scope of this license may be available if you contact us with your request. If you want to revise a translation, use a translation in an adaptation, or use a translation commercially, we will relay your request to the appropriate copyright owner.
* Source: http://pngscriptures.org/aai/
* Version: v0
* Language name: Arifama-Miniafia
* Homepage: http://paralleltext.info/data/aai-x-bible-arifa-v0
* ISO 639-3: aai

* Last modified: 2013-11-07

Resources
---------

1. Path: aai-x-bible-arifa-v0.mtx
	Format: mtx
2. Path: aai-x-bible-arifa-v0.wordforms
	Format: csv
3. Path: aai-x-bible-arifa-v0.txt
	Format: csv
4. Path: versenames-v1.txt
	Format: csv
5. Path: README.md
	Format: md
	
Project
-------

* Name: Parallel Bible Corpus
* URL: http://paralleltext.info

Maintainers
-----------

* Thomas Mayer
	thomas.mayer@uni-marburg.de
	http://th-mayer.de
* Michael Cysouw
	cysouw@uni-marburg.de
